// used at Admin Page
export interface UserThumbnail {
  username : string
  joinDate : string
  approved : boolean
  // user , admin-navigation-panel
  role : string
}
