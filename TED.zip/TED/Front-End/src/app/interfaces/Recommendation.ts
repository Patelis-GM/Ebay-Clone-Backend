// TODO

export interface Recommendation{

  var : string

}
