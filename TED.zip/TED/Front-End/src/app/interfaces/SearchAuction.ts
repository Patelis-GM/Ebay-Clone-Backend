
export interface SearchAuction {

  auctionText : string
  auctionCategory : string

}
