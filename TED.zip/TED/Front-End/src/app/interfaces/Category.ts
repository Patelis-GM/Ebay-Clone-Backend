
export interface Category {

  categoryName : string

}
