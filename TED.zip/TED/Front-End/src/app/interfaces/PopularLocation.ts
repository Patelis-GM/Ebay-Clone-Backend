
export interface PopularLocation {

  locationName : string

}
