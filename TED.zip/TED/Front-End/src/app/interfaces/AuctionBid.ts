export interface AuctionBid{
  id: number
  bidder: string
  bidderRating: number
  amount: number
  submissionDate: string
}
