export interface Bid{
  version: string
  amount: string
}
