export interface BidThumbnail{

  auctionID : number
  auctionName : string
  amount : number
  submissionDate : string
  images: any[]
}
