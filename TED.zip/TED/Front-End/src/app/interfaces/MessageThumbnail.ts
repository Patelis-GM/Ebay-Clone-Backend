
export interface MessageThumbnail{

  id: number
  title: string
  body: string
  creationDate: string
  read: boolean
  sender: string
  recipient: string

}
