
export interface PurchaseThumbnail{

  id : number
  name : string
  seller : string
  cost: number
  date : string
  images : any[]

}
