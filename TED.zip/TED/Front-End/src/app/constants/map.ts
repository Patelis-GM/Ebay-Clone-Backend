
export const mapLinks = [
  // link #1
  "http://tile.openstreetmap.org/{z}/{x}/{y}.png"
  //link #2
]
