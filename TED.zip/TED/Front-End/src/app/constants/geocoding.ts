

export const geocodingLinks = [

  // for forward geocoding
  "https://api.locationiq.com/v1/autocomplete.php",
  // for reverse geocoding
  "https://eu1.locationiq.com/v1/reverse.php"

]

export const geocodingKeys = [
  // current key
  "pk.48a73ae665bee61996f92137029f6a70",
  // emergency key
  "pk.2191e0641f3fafa3e3cce39591faf310"

]
