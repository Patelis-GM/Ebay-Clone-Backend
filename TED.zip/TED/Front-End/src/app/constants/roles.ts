

export const roles = [
  "GUEST",
  "USER",
  "ADMIN"
]

