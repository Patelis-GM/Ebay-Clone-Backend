

export const searchOptions = [
  "My Bids",
  "My Purchases",
  "My Auctions",
  "My Messages"
]


export const buttonOptions = {
  administration : "Administration",
  categories: "Categories",
  shopByCategory: "Shop By Category",
  login: "Login"
}
